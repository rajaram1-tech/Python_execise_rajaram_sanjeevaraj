# Student Management System

A comprehensive web-based Student Management System built with Flask and MySQL. This application allows administrators to manage student records, track academic performance, and handle contact inquiries.

## Features

### 🎓 Core Features
- **User Authentication**: Secure registration and login system
- **Student Management**: Complete student profile management
- **Academic Tracking**: Marks and grade management system
- **Subject Management**: Pre-configured subjects with grading
- **Admin Dashboard**: Comprehensive administrative interface
- **Contact System**: Built-in contact form and message management

### 🔐 User Roles
- **Students**: View personal dashboard, check marks and grades
- **Administrators**: Manage all students, add marks, view messages

### 📊 Academic Features
- **Grading System**: A+ to F grade calculation
- **Subject Tracking**: Mathematics, Physics, Chemistry, English, Computer Science
- **Performance Analytics**: Average marks calculation and performance indicators
- **Export Functionality**: CSV export for student data

## Technology Stack

- **Backend**: Python Flask
- **Database**: MySQL
- **Frontend**: HTML5, CSS3, Bootstrap 5
- **Security**: Bcrypt password hashing
- **Icons**: Font Awesome

## Installation & Setup

### Prerequisites
- Python 3.7+
- MySQL Server
- pip (Python package manager)

### Step 1: Clone/Download the Project
```bash
# If using git
git clone <repository-url>
cd Final_project

# Or download and extract the ZIP file
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Database Setup

#### Option A: Using XAMPP (Recommended for beginners)
1. Download and install [XAMPP](https://www.apachefriends.org/)
2. Start Apache and MySQL from XAMPP Control Panel
3. Open phpMyAdmin: http://localhost/phpmyadmin
4. Create a new database named `student_management`

#### Option B: Standalone MySQL
1. Install MySQL Server
2. Start MySQL service
3. Create database:
   ```sql
   CREATE DATABASE student_management;
   ```

### Step 4: Configure Database Connection
Edit `app.py` and update MySQL settings:
```python
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = ''  # Your MySQL password
app.config['MYSQL_DATABASE_DB'] = 'student_management'
```

### Step 5: Run the Application
```bash
python app.py
```

The application will be available at: http://localhost:5000

## Usage Guide

### First Time Setup

1. **Start the Application**: The system will automatically create all required database tables
2. **Create Admin User**: Run the admin creation script:
   ```bash
   python create_admin.py
   ```
3. **Access the System**: Open http://localhost:5000 in your browser

### For Students

1. **Register**: Click "Register" and fill in your details
2. **Login**: Use your username and password to login
3. **View Dashboard**: Check your personal information and academic performance
4. **Contact Support**: Use the contact form for any inquiries

### For Administrators

1. **Login**: Use admin credentials created during setup
2. **Manage Students**: View all students from the admin dashboard
3. **Add Marks**: Use "Add Marks" to record student performance
4. **View Messages**: Check and respond to contact inquiries
5. **Export Data**: Download student data as CSV

## File Structure

```
Final_project/
├── app.py                 # Main Flask application
├── create_admin.py        # Admin user creation script
├── requirements.txt       # Python dependencies
├── DATABASE_SETUP.md     # Database setup instructions
├── README.md             # This file
├── static/
│   └── css/
│       └── style.css     # Custom styles
└── templates/
    ├── base.html         # Base template
    ├── index.html        # Homepage
    ├── login.html        # Login page
    ├── register.html     # Registration page
    ├── student_dashboard.html    # Student dashboard
    ├── admin_dashboard.html      # Admin dashboard
    ├── add_marks.html    # Add marks form
    ├── contact.html      # Contact page
    └── view_messages.html # Admin message viewer
```

## Database Schema

### Tables Created Automatically
- **users**: User authentication and roles
- **students**: Student personal information
- **subjects**: Available subjects and codes
- **marks**: Student marks and grades
- **contact_messages**: Contact form submissions

## Grading System

| Marks Range | Grade | Description |
|-------------|-------|-------------|
| 90-100      | A+    | Excellent   |
| 80-89       | A     | Very Good   |
| 70-79       | B+    | Good        |
| 60-69       | B     | Satisfactory|
| 50-59       | C     | Average     |
| 40-49       | D     | Pass        |
| 0-39        | F     | Fail        |

## Default Subjects

1. Mathematics (MATH101) - 4 Credits
2. Physics (PHY101) - 3 Credits
3. Chemistry (CHEM101) - 3 Credits
4. English (ENG101) - 2 Credits
5. Computer Science (CS101) - 4 Credits

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Ensure MySQL is running
   - Check database credentials in app.py
   - Verify database exists

2. **Import Errors**
   - Install requirements: `pip install -r requirements.txt`
   - Use virtual environment if needed

3. **Permission Denied**
   - Run terminal as administrator
   - Check MySQL user permissions

4. **Port Already in Use**
   - Stop other Flask applications
   - Change port in app.py: `app.run(port=5001)`

### Development Tips

- Set `debug=False` in production
- Use virtual environment for package isolation
- Regular database backups recommended
- Update secret key for production use

## Security Features

- Password hashing with bcrypt
- Session management
- SQL injection protection with parameterized queries
- XSS protection through template escaping
- CSRF protection (can be enhanced with Flask-WTF)

## Future Enhancements

- Email notifications
- File upload for documents
- Advanced reporting
- Attendance tracking
- Fee management
- Mobile responsive improvements

## Support

For technical support or questions:
- Use the built-in contact form
- Check the troubleshooting section
- Review the database setup guide

## License

This project is created for educational purposes. Feel free to modify and use according to your needs.

---

**Created by**: Student Management System Team  
**Version**: 1.0.0  
**Last Updated**: August 2025
