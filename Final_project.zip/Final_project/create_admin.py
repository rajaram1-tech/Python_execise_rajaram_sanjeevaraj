"""
Admin User Creation Script
Run this script to create an admin user for the Student Management System
"""

import pymysql
import bcrypt

def create_admin_user():
    # Database connection details
    host = 'localhost'
    user = 'root'
    password = ''  # Change this to your MySQL password
    database = 'student_management'
    
    try:
        # Connect to database
        connection = pymysql.connect(
            host=host,
            user=user,
            password=password,
            database=database,
            charset='utf8mb4'
        )
        
        cursor = connection.cursor()
        
        # Admin user details
        admin_username = input("Enter admin username (default: admin): ") or "admin"
        admin_email = input("Enter admin email (default: admin@example.com): ") or "admin@example.com"
        admin_password = input("Enter admin password (default: admin123): ") or "admin123"
        
        # Hash the password
        hashed_password = bcrypt.hashpw(admin_password.encode('utf-8'), bcrypt.gensalt())
        
        # Insert admin user
        cursor.execute("""
            INSERT INTO users (username, email, password, role) 
            VALUES (%s, %s, %s, %s)
        """, (admin_username, admin_email, hashed_password, 'admin'))
        
        connection.commit()
        print(f"\nAdmin user '{admin_username}' created successfully!")
        print(f"Login credentials:")
        print(f"Username: {admin_username}")
        print(f"Password: {admin_password}")
        print(f"Email: {admin_email}")
        
    except pymysql.Error as e:
        print(f"Error: {e}")
        
    except Exception as e:
        print(f"Unexpected error: {e}")
        
    finally:
        if 'connection' in locals():
            connection.close()

if __name__ == "__main__":
    print("Student Management System - Admin User Creation")
    print("=" * 50)
    create_admin_user()
