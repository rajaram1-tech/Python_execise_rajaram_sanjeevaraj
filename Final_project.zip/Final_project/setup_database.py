import pymysql
import bcrypt

def create_database():
    """Create the student_management database if it doesn't exist"""
    try:
        # Connect to MySQL server (without specifying database)
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='',  # Default XAMPP MySQL password is empty
            charset='utf8mb4'
        )
        
        cursor = connection.cursor()
        
        # Create database
        cursor.execute("CREATE DATABASE IF NOT EXISTS student_management")
        print("Database 'student_management' created successfully!")
        
        # Switch to the new database
        cursor.execute("USE student_management")
        
        # Create users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role ENUM('admin', 'student') DEFAULT 'student',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        print("Users table created successfully!")
        
        # Create students table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS students (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                phone VARCHAR(15),
                address TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        print("Students table created successfully!")
        
        # Create subjects table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS subjects (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                code VARCHAR(20) UNIQUE NOT NULL,
                credits INT DEFAULT 3
            )
        ''')
        print("Subjects table created successfully!")
        
        # Create marks table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS marks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                student_id INT,
                subject_id INT,
                marks INT NOT NULL,
                grade VARCHAR(2),
                exam_date DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (student_id) REFERENCES students(id),
                FOREIGN KEY (subject_id) REFERENCES subjects(id)
            )
        ''')
        print("Marks table created successfully!")
        
        # Create contact messages table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS contact_messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                subject VARCHAR(200),
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        print("Contact messages table created successfully!")
        
        # Insert default subjects
        cursor.execute('''
            INSERT IGNORE INTO subjects (name, code, credits) VALUES
            ('Mathematics', 'MATH101', 4),
            ('Physics', 'PHY101', 3),
            ('Chemistry', 'CHEM101', 3),
            ('English', 'ENG101', 2),
            ('Computer Science', 'CS101', 4)
        ''')
        print("Default subjects added successfully!")
        
        # Create default admin user
        admin_password = 'admin123'
        hashed_password = bcrypt.hashpw(admin_password.encode('utf-8'), bcrypt.gensalt())
        
        try:
            cursor.execute('''
                INSERT INTO users (username, email, password, role)
                VALUES (%s, %s, %s, %s)
            ''', ('admin', 'admin@example.com', hashed_password, 'admin'))
            print("Default admin user created successfully!")
            print("Admin credentials: username='admin', password='admin123'")
        except pymysql.IntegrityError:
            print("Admin user already exists!")
        
        connection.commit()
        cursor.close()
        connection.close()
        print("\nDatabase setup completed successfully!")
        print("You can now run your Flask application with: python app.py")
        
    except Exception as e:
        print(f"Error setting up database: {e}")
        print("\nPlease make sure:")
        print("1. XAMPP MySQL service is running")
        print("2. MySQL is accessible on localhost:3306")
        print("3. Root user has no password (default XAMPP setting)")

if __name__ == '__main__':
    create_database()
