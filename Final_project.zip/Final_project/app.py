from flask import Flask, render_template, request, redirect, url_for, flash, session
from flaskext.mysql import MySQL
import pymysql
import bcrypt
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# MySQL Configuration
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = ''  # Change this to your MySQL password
app.config['MYSQL_DATABASE_DB'] = 'student_management'

mysql = MySQL()
mysql.init_app(app)

def create_tables():
    """Create necessary tables if they don't exist"""
    try:
        conn = mysql.connect()
        cursor = conn.cursor()
        
        # Create users table for login/registration
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role ENUM('admin', 'student') DEFAULT 'student',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create students table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS students (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                phone VARCHAR(15),
                address TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        # Create subjects table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS subjects (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                code VARCHAR(20) UNIQUE NOT NULL,
                credits INT DEFAULT 3
            )
        ''')
        
        # Create marks table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS marks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                student_id INT,
                subject_id INT,
                marks INT NOT NULL,
                grade VARCHAR(2),
                exam_date DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (student_id) REFERENCES students(id),
                FOREIGN KEY (subject_id) REFERENCES subjects(id)
            )
        ''')
        
        # Create contact messages table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS contact_messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                subject VARCHAR(200),
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Insert some default subjects
        cursor.execute('''
            INSERT IGNORE INTO subjects (name, code, credits) VALUES
            ('Mathematics', 'MATH101', 4),
            ('Physics', 'PHY101', 3),
            ('Chemistry', 'CHEM101', 3),
            ('English', 'ENG101', 2),
            ('Computer Science', 'CS101', 4)
        ''')
        
        conn.commit()
        cursor.close()
        conn.close()
        print("Tables created successfully!")
    except Exception as e:
        print(f"Error creating tables: {e}")

def calculate_grade(marks):
    """Calculate grade based on marks"""
    if marks >= 90:
        return 'A+'
    elif marks >= 80:
        return 'A'
    elif marks >= 70:
        return 'B+'
    elif marks >= 60:
        return 'B'
    elif marks >= 50:
        return 'C'
    elif marks >= 40:
        return 'D'
    else:
        return 'F'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        name = request.form['name']
        phone = request.form['phone']
        address = request.form['address']
        
        # Hash password
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        
        try:
            conn = mysql.connect()
            cursor = conn.cursor()
            
            # Insert user
            cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                         (username, email, hashed_password))
            user_id = cursor.lastrowid
            
            # Insert student details
            cursor.execute("INSERT INTO students (user_id, name, email, phone, address) VALUES (%s, %s, %s, %s, %s)",
                         (user_id, name, email, phone, address))
            
            conn.commit()
            cursor.close()
            conn.close()
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
            
        except Exception as e:
            flash(f'Registration failed: {str(e)}', 'error')
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        try:
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute("SELECT id, username, password, role FROM users WHERE username = %s", (username,))
            user = cursor.fetchone()
            
            if user and bcrypt.checkpw(password.encode('utf-8'), user[2].encode('utf-8')):
                session['user_id'] = user[0]
                session['username'] = user[1]
                session['role'] = user[3]
                flash('Login successful!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid username or password!', 'error')
                
            cursor.close()
            conn.close()
            
        except Exception as e:
            flash(f'Login failed: {str(e)}', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out successfully!', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please login to access dashboard!', 'error')
        return redirect(url_for('login'))
    
    try:
        conn = mysql.connect()
        cursor = conn.cursor()
        
        if session['role'] == 'admin':
            # Admin dashboard - show all students
            cursor.execute('''
                SELECT s.id, s.name, s.email, s.phone, 
                       COUNT(m.id) as total_subjects,
                       AVG(m.marks) as avg_marks
                FROM students s
                LEFT JOIN marks m ON s.id = m.student_id
                GROUP BY s.id
            ''')
            students = cursor.fetchall()
            cursor.close()
            conn.close()
            return render_template('admin_dashboard.html', students=students)
        else:
            # Student dashboard - show own details and marks
            cursor.execute("SELECT id FROM students WHERE user_id = %s", (session['user_id'],))
            student = cursor.fetchone()
            
            if student:
                student_id = student[0]
                cursor.execute('''
                    SELECT sub.name, m.marks, m.grade, m.exam_date
                    FROM marks m
                    JOIN subjects sub ON m.subject_id = sub.id
                    WHERE m.student_id = %s
                    ORDER BY m.exam_date DESC
                ''', (student_id,))
                marks = cursor.fetchall()
                
                cursor.execute("SELECT name, email, phone, address FROM students WHERE id = %s", (student_id,))
                student_info = cursor.fetchone()
                
                cursor.close()
                conn.close()
                return render_template('student_dashboard.html', marks=marks, student_info=student_info)
            else:
                flash('Student profile not found!', 'error')
                return redirect(url_for('index'))
                
    except Exception as e:
        flash(f'Error loading dashboard: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/add_marks', methods=['GET', 'POST'])
def add_marks():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Access denied!', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        student_id = request.form['student_id']
        subject_id = request.form['subject_id']
        marks = int(request.form['marks'])
        exam_date = request.form['exam_date']
        
        grade = calculate_grade(marks)
        
        try:
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO marks (student_id, subject_id, marks, grade, exam_date)
                VALUES (%s, %s, %s, %s, %s)
            ''', (student_id, subject_id, marks, grade, exam_date))
            conn.commit()
            cursor.close()
            conn.close()
            flash('Marks added successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error adding marks: {str(e)}', 'error')
    
    try:
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM students")
        students = cursor.fetchall()
        cursor.execute("SELECT id, name, code FROM subjects")
        subjects = cursor.fetchall()
        cursor.close()
        conn.close()
        return render_template('add_marks.html', students=students, subjects=subjects)
    except Exception as e:
        flash(f'Error loading form: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        subject = request.form['subject']
        message = request.form['message']
        
        try:
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO contact_messages (name, email, subject, message)
                VALUES (%s, %s, %s, %s)
            ''', (name, email, subject, message))
            conn.commit()
            cursor.close()
            conn.close()
            flash('Your message has been sent successfully!', 'success')
            return redirect(url_for('contact'))
        except Exception as e:
            flash(f'Error sending message: {str(e)}', 'error')
    
    return render_template('contact.html')

@app.route('/view_messages')
def view_messages():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Access denied!', 'error')
        return redirect(url_for('index'))
    
    try:
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM contact_messages ORDER BY created_at DESC")
        messages = cursor.fetchall()
        cursor.close()
        conn.close()
        return render_template('view_messages.html', messages=messages)
    except Exception as e:
        flash(f'Error loading messages: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

if __name__ == '__main__':
    create_tables()
    app.run(debug=True)