import pymysql

def test_database_connection():
    """Test the database connection and show table information"""
    try:
        # Connect to the database
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='',
            database='student_management',
            charset='utf8mb4'
        )
        
        cursor = connection.cursor()
        
        print("✅ Successfully connected to MySQL database!")
        print("📊 Database: student_management")
        print("-" * 50)
        
        # Show all tables
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        print("📋 Tables in database:")
        for table in tables:
            print(f"   • {table[0]}")
        
        print("-" * 50)
        
        # Show user count
        cursor.execute("SELECT COUNT(*) FROM users")
        user_count = cursor.fetchone()[0]
        print(f"👥 Total users: {user_count}")
        
        # Show admin users
        cursor.execute("SELECT username, email, role FROM users WHERE role = 'admin'")
        admins = cursor.fetchall()
        print("🔐 Admin users:")
        for admin in admins:
            print(f"   • Username: {admin[0]}, Email: {admin[1]}")
        
        # Show subjects count
        cursor.execute("SELECT COUNT(*) FROM subjects")
        subject_count = cursor.fetchone()[0]
        print(f"📚 Total subjects: {subject_count}")
        
        # Show subjects
        cursor.execute("SELECT name, code FROM subjects")
        subjects = cursor.fetchall()
        print("📖 Available subjects:")
        for subject in subjects:
            print(f"   • {subject[1]}: {subject[0]}")
        
        cursor.close()
        connection.close()
        
        print("-" * 50)
        print("✅ Database connection test completed successfully!")
        print("🚀 Your Flask application is ready to run!")
        
    except Exception as e:
        print(f"❌ Error connecting to database: {e}")
        print("\n🔧 Troubleshooting tips:")
        print("1. Make sure XAMPP MySQL service is running")
        print("2. Check if MySQL is running on port 3306")
        print("3. Verify that root user has no password")
        print("4. Ensure 'student_management' database exists")

if __name__ == '__main__':
    test_database_connection()
