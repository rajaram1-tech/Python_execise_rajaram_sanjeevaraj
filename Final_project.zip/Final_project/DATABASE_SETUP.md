# Student Management System Database Setup

This script helps you set up the MySQL database for the Student Management System.

## Prerequisites

1. **Install MySQL Server**
   - Download from: https://dev.mysql.com/downloads/mysql/
   - Or install XAMPP for an easier setup: https://www.apachefriends.org/

2. **Start MySQL Service**
   - If using XAMPP: Start Apache and MySQL from the control panel
   - If using standalone MySQL: Start the MySQL service

## Database Setup Instructions

### Option 1: Using MySQL Command Line

1. Open MySQL command line or phpMyAdmin
2. Create the database:
   ```sql
   CREATE DATABASE student_management;
   ```

3. Create an admin user (optional, for testing):
   ```sql
   USE student_management;
   
   -- First create a regular user account
   INSERT INTO users (username, email, password, role) 
   VALUES ('admin', 'admin@example.com', '$2b$12$LGGJKjJHwzm8LxwMhNFqGOYHKUTxkGgYLKe5eJjGDNWO7VUkwMdza', 'admin');
   -- Password is: admin123
   ```

### Option 2: Using phpMyAdmin (if using XAMPP)

1. Open http://localhost/phpmyadmin
2. Click "New" to create a new database
3. Name it "student_management"
4. The application will automatically create the required tables

## Configuration

1. Open `app.py`
2. Update the MySQL configuration:
   ```python
   app.config['MYSQL_DATABASE_HOST'] = 'localhost'
   app.config['MYSQL_DATABASE_USER'] = 'root'
   app.config['MYSQL_DATABASE_PASSWORD'] = ''  # Your MySQL password
   app.config['MYSQL_DATABASE_DB'] = 'student_management'
   ```

## Running the Application

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   python app.py
   ```

3. Open your browser and go to: http://localhost:5000

## Default Accounts

After running the application, you can:

1. **Register as a Student**: Use the registration form
2. **Admin Access**: You'll need to manually create an admin account in the database

## Troubleshooting

1. **Database Connection Error**: 
   - Ensure MySQL is running
   - Check your database credentials in `app.py`
   - Make sure the database exists

2. **Import Errors**:
   - Install all requirements: `pip install -r requirements.txt`

3. **Permission Errors**:
   - Ensure MySQL user has proper permissions
   - Try running as administrator if needed

## Features

- User Registration & Login
- Student Profile Management
- Marks & Grade Management
- Admin Dashboard
- Contact System
- Responsive Design
