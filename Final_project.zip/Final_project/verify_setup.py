"""
Student Management System - Final Setup Verification
==================================================

This script verifies that your student management system is properly
connected to MySQL and ready to use.
"""

import pymysql
import sys
from datetime import datetime

def check_mysql_connection():
    """Check if MySQL is running and accessible"""
    try:
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='',
            charset='utf8mb4'
        )
        connection.close()
        return True, "✅ MySQL server is running and accessible"
    except Exception as e:
        return False, f"❌ MySQL connection failed: {e}"

def check_database_exists():
    """Check if the student_management database exists"""
    try:
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='',
            database='student_management',
            charset='utf8mb4'
        )
        connection.close()
        return True, "✅ Database 'student_management' exists and is accessible"
    except Exception as e:
        return False, f"❌ Database check failed: {e}"

def check_tables():
    """Check if all required tables exist"""
    required_tables = ['users', 'students', 'subjects', 'marks', 'contact_messages']
    try:
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='',
            database='student_management',
            charset='utf8mb4'
        )
        cursor = connection.cursor()
        cursor.execute("SHOW TABLES")
        existing_tables = [table[0] for table in cursor.fetchall()]
        
        missing_tables = [table for table in required_tables if table not in existing_tables]
        
        if not missing_tables:
            return True, f"✅ All required tables exist: {', '.join(existing_tables)}"
        else:
            return False, f"❌ Missing tables: {', '.join(missing_tables)}"
    except Exception as e:
        return False, f"❌ Table check failed: {e}"

def check_admin_user():
    """Check if admin user exists"""
    try:
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='',
            database='student_management',
            charset='utf8mb4'
        )
        cursor = connection.cursor()
        cursor.execute("SELECT username, email FROM users WHERE role = 'admin'")
        admins = cursor.fetchall()
        
        if admins:
            admin_info = ', '.join([f"{admin[0]} ({admin[1]})" for admin in admins])
            return True, f"✅ Admin user(s) exist: {admin_info}"
        else:
            return False, "❌ No admin users found"
    except Exception as e:
        return False, f"❌ Admin user check failed: {e}"

def check_subjects():
    """Check if default subjects exist"""
    try:
        connection = pymysql.connect(
            host='localhost',
            user='root',
            password='',
            database='student_management',
            charset='utf8mb4'
        )
        cursor = connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM subjects")
        subject_count = cursor.fetchone()[0]
        
        if subject_count >= 5:
            return True, f"✅ {subject_count} subjects configured"
        else:
            return False, f"❌ Only {subject_count} subjects found (expected 5+)"
    except Exception as e:
        return False, f"❌ Subject check failed: {e}"

def print_header():
    """Print a nice header"""
    print("=" * 60)
    print("🎓 STUDENT MANAGEMENT SYSTEM - SETUP VERIFICATION")
    print("=" * 60)
    print(f"📅 Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()

def print_summary(checks):
    """Print summary of all checks"""
    print("\n" + "=" * 60)
    print("📋 VERIFICATION SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for success, _ in checks if success)
    total = len(checks)
    
    print(f"✅ Passed: {passed}/{total}")
    print(f"❌ Failed: {total - passed}/{total}")
    
    if passed == total:
        print("\n🎉 ALL CHECKS PASSED!")
        print("🚀 Your Student Management System is ready to use!")
        print("\n📝 Next Steps:")
        print("   1. Run: start.bat (or python app.py)")
        print("   2. Open: http://localhost:5000")
        print("   3. Login with: admin / admin123")
    else:
        print("\n⚠️  SOME CHECKS FAILED!")
        print("🔧 Please fix the issues above before running the application.")
        print("\n💡 Troubleshooting:")
        print("   1. Make sure XAMPP MySQL is running")
        print("   2. Run: python setup_database.py")
        print("   3. Check MySQL configuration in app.py")

def main():
    """Run all verification checks"""
    print_header()
    
    checks = [
        ("MySQL Connection", check_mysql_connection),
        ("Database Exists", check_database_exists),
        ("Tables Created", check_tables),
        ("Admin User", check_admin_user),
        ("Default Subjects", check_subjects)
    ]
    
    results = []
    
    for check_name, check_function in checks:
        print(f"🔍 Checking {check_name}...")
        success, message = check_function()
        results.append((success, message))
        print(f"   {message}")
        print()
    
    print_summary(results)

if __name__ == '__main__':
    main()
